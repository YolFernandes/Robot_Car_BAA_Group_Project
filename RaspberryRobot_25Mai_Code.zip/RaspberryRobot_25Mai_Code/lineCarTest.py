#
# Python Rover (PRover)
#
# the Gertbot drivers
import cherrypy
import gertbot as gb
import RPi.GPIO as GPIO
import string
import time
import curses 
from subprocess import check_output


ipaddr = check_output(['hostname','-I']).strip().decode('utf-8')

file = open ('/home/pi/index_lineCar.html')
html_index = file.read()
file.close()
html_index = html_index.format(IP=ipaddr)

# This is for the development environment:
#BOARD = 1           # Which board we talk to 
#LEFT  = 0           # channel for left track
#RIGHT = 2           # channel for right track

# This is for on the rover:
BOARD = 0           # Which board we talk to 
LEFT  = 0           # channel for left track
RIGHT = 1           # channel for right track

# Forards and backwards are the same for left and right
# The trick is to reverse the motor connections for one  :-) 
RAMP  = gb.RAMP_050 # ramp speed=0.5 seconds
FORWD = gb.MOVE_A
BACKW = gb.MOVE_B
STOP  = gb.MOVE_STOP


# 
# gb.move_brushed(board,channel,direction)
#                 ^^^^^ ^^^^^^^ ^^^^^^^^^ 
#                 ||||| ||||||| ||||||||| 
#                 ||||| ||||||| ||||||||| 
#                 ||||| ||||||| +++++++++--------< Left, right, stop
#                 ||||| +++++++------------------< Which motor on board 0,1,2,3
#                 +++++--------------------------< which board 0,1,2,3


# Main program

screen = curses.initscr()
  
# Open serial port to talk to Gertbot 
gb.open_uart(0)

# Setup the channels for brushed motors
gb.set_mode(BOARD,LEFT,gb.MODE_BRUSH)
gb.set_mode(BOARD,RIGHT,gb.MODE_BRUSH)
# set a ramp-up speed in case motors are big
gb.set_brush_ramps(BOARD,LEFT, RAMP,RAMP,0);
gb.set_brush_ramps(BOARD,RIGHT,RAMP,RAMP,0);

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#first IR sensor
GPIO.setup(13, GPIO.IN)

#Second IR sensor
GPIO.setup(19, GPIO.IN)

#Third IR sensor
GPIO.setup(26, GPIO.IN)


f = 5000
x = 60
y = 53
z = 20
stop = 0
offSet = 0



class carController(object):

    global html_index

    @cherrypy.expose
    def index(self):
        
        return html_index

    @cherrypy.expose
    def GO(self):            
        lIr = GPIO.input(13)
        mIr = GPIO.input(19)
        rIr = GPIO.input(26)
        time.sleep(0.01)

        if  lIr == 1 and mIr == 0 and rIr == 1:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,x)
            gb.pwm_brushed(BOARD,LEFT,f,x)
            offSet = 0

        elif  lIr == 1 and mIr == 1 and rIr == 0:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.pwm_brushed(BOARD,LEFT,f,x)
            gb.pwm_brushed(BOARD,RIGHT,f,z)
            gb.move_brushed(BOARD,LEFT,FORWD)
            offSet == 1

        elif  lIr == 0 and mIr == 1 and rIr == 1:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,x)
            gb.pwm_brushed(BOARD,LEFT,f,z)
            offSet = 2

        elif  lIr == 1 and mIr == 0 and rIr == 0:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,y)
            gb.pwm_brushed(BOARD,LEFT,f,x)
            offSet = 1

        elif  lIr == 0 and mIr == 0 and rIr == 1:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,x)
            gb.pwm_brushed(BOARD,LEFT,f,y)
            offSet = 2

        elif lIr == 1 and mIr == 1 and rIr == 1 and offSet == 1:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,z)
            gb.pwm_brushed(BOARD,LEFT,f,y)
            offset = 1

        elif lIr == 1 and mIr == 1 and rIr == 1 and offSet == 2:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,y)
            gb.pwm_brushed(BOARD,LEFT,f,z)
            offset = 2

        else :
            gb.move_brushed(BOARD, RIGHT, STOP)
            gb.move_brushed(BOARD, LEFT, STOP)
            time.sleep (0.5)
            gb.move_brushed(BOARD, RIGHT, FORWD)
            gb.move_brushed(BOARD, LEFT, BACKW)
            time.sleep(1.5)
            run = 0


    def STOP(self):
            run = 0


cherrypy.server.socket_host = ipaddr
cherrypy.quickstart(carController())



# on exit stop everything
gb.emergency_stop()
# Set terminal behaviour normal again
curses.endwin()

