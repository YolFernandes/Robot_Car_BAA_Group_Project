#!/usr/bin/python

import time
import datetime
import RPi.GPIO as GPIO
import gertbot as gb
import string
from subprocess import check_output

# This is for on the rover:
BOARD = 0           # Which board we talk to 
LEFT  = 0           # channel for left track
RIGHT = 1           # channel for right track

# Forards and backwards are the same for left and right
# The trick is to reverse the motor connections for one  :-) 
RAMP  = gb.RAMP_050 # ramp speed=0.5 seconds
FORWD = gb.MOVE_A
BACKW = gb.MOVE_B
STOP  = gb.MOVE_STOP


# 
# gb.move_brushed(board,channel,direction)
#                 ^^^^^ ^^^^^^^ ^^^^^^^^^ 
#                 ||||| ||||||| ||||||||| 
#                 ||||| ||||||| ||||||||| 
#                 ||||| ||||||| +++++++++--------< Left, right, stop
#                 ||||| +++++++------------------< Which motor on board 0,1,2,3
#                 +++++--------------------------< which board 0,1,2,3


# Main program

  
# Open serial port to talk to Gertbot 
gb.open_uart(0)

# Setup the channels for brushed motors
gb.set_mode(BOARD,LEFT,gb.MODE_BRUSH)
gb.set_mode(BOARD,RIGHT,gb.MODE_BRUSH)
# set a ramp-up speed in case motors are big
gb.set_brush_ramps(BOARD,LEFT, RAMP,RAMP,0);
gb.set_brush_ramps(BOARD,RIGHT,RAMP,RAMP,0);

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

#first sensor
GPIO.setup(40,GPIO.OUT)
GPIO.setup(38,GPIO.IN)

#second sensor
GPIO.setup(36,GPIO.OUT)
GPIO.setup(32,GPIO.IN)

a = 2.200
f = 5000
x = 100
y = 40
distance1=0
distance2=0

def reading1(sensor1):
    pingtime1 = 0
    echotime1 = 0
    global distance1

    if sensor1 == 0:
        GPIO.output(40,GPIO.LOW)

        GPIO.output(40,GPIO.HIGH)
        pingtime1=time.time()
        time.sleep(0.001)
        GPIO.output(40,GPIO.LOW)

        while GPIO.input(38)==0:
            pingtime1 = time.time()

        while GPIO.input(38)==1:
            echotime1=time.time()

        if (echotime1 is not None) and (pingtime1 is not None):
            elapsedtime1 = echotime1 - pingtime1
            distance1 = elapsedtime1 * 17000
        else:
            distance1 = 0

        return distance1

def reading2(sensor2):
    pingtime2 = 0
    echotime2 = 0
    global distance2

    if sensor2 == 0:
        GPIO.output(36,GPIO.LOW)

        GPIO.output(36,GPIO.HIGH)
        pingtime2=time.time()
        time.sleep(0.001)
        GPIO.output(36,GPIO.LOW)

        while GPIO.input(32)==0:
            pingtime2 = time.time()
            
        while GPIO.input(32)==1:
            echotime2=time.time()
        
        if (echotime2 is not None) and (pingtime2 is not None):
            elapsedtime2 = echotime2 - pingtime2
            distance2 = elapsedtime2 * 17000
        else:
            distance2 = 0
                
        return distance2

while True:    
    try:
        adc0 = gb.read_adc(0,0)
        adc1 = gb.read_adc(0,1)
        adc2 = gb.read_adc(0,2)
        '''
        print("ADC0 : %6.3f" % adc0)
        print("ADC1 : %6.3f" % adc1)
        print("ADC2 : %6.3f" % adc2)
        '''
        time.sleep(0.001)

        if adc0 > a or adc1 > a or adc2 > a:
            '''
            range1 = reading1(0)
            range2 = reading2(0)
            print(range1)
            print(range2)
            '''
            
            if distance1 < 40 and distance2 < 40:
                gb.move_brushed(BOARD,LEFT,FORWD)
                gb.pwm_brushed(BOARD,LEFT,f,x-5)
                gb.move_brushed(BOARD,RIGHT,FORWD)
                gb.pwm_brushed(BOARD,RIGHT,f,x)

            elif distance1 < 40 and distance2 > 100:
                gb.move_brushed(BOARD,LEFT,FORWD)
                gb.pwm_brushed(BOARD,LEFT,f,x)
                gb.move_brushed(BOARD,RIGHT,FORWD)
                gb.pwm_brushed(BOARD,RIGHT,f,x-10)
        
            elif distance1 < 100 and distance1 > 40 and distance2 >= 40:
                gb.move_brushed(BOARD,LEFT,FORWD)
                gb.pwm_brushed(BOARD,LEFT,f,y)
                gb.move_brushed(BOARD,RIGHT,FORWD)
                gb.pwm_brushed(BOARD,RIGHT,f,y)

            elif distance1 < 100 and distance1 > 40 and distance2 < 100 and distance2 > 40:
                gb.move_brushed(BOARD,LEFT,FORWD)
                gb.pwm_brushed(BOARD,LEFT,f,y)
                gb.move_brushed(BOARD,RIGHT,FORWD)
                gb.pwm_brushed(BOARD,RIGHT,f,y+5)

            elif distance1 > 100 and distance2 < 100 and distance2 >40:
                gb.move_brushed(BOARD,LEFT,FORWD)
                gb.pwm_brushed(BOARD,LEFT,f,y-5)
                gb.move_brushed(BOARD,RIGHT,FORWD)
                gb.pwm_brushed(BOARD,RIGHT,f,y+5)
    
            elif distance1 > 100 and distance2 < 40:
                gb.move_brushed(BOARD,LEFT,FORWD)
                gb.pwm_brushed(BOARD,LEFT,f,x-20)
                gb.move_brushed(BOARD,RIGHT,FORWD)
                gb.pwm_brushed(BOARD,RIGHT,f,x)

            else:
                gb.move_brushed(BOARD,LEFT,FORWD)
                gb.pwm_brushed(BOARD,LEFT,f,y)
                gb.move_brushed(BOARD,RIGHT,BACKW)
                gb.pwm_brushed(BOARD,RIGHT,f,y+5)
                
        else:
            gb.move_brushed(BOARD,LEFT,BACKW)
            gb.pwm_brushed(BOARD,LEFT,f,y)
            gb.move_brushed(BOARD,RIGHT,BACKW)
            gb.pwm_brushed(BOARD,RIGHT,f,y+5)
            time.sleep(1)
    
    except KeyboardInterrupt:
        run = 0
        break
	
# on exit stop everything
gb.emergency_stop()

