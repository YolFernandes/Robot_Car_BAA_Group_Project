import gertbot as gb
import RPi.GPIO as GPIO
import time

# Open the serial connection from RPi to Gertbot
gb.open_uart(0)

# Ensure that the relevant pins are active as ADC input

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

#first IR sensor
GPIO.setup(33, GPIO.IN)

#Second IR sensor
GPIO.setup(35, GPIO.IN)

#Third IR sensor
GPIO.setup(37, GPIO.IN)


while True:
        lIr = GPIO.input(33)
        mIr = GPIO.input(35)
        rIr = GPIO.input(37)

        print(lIr)
        print(mIr)
        print(rIr)
        time.sleep(1)
        print(' ')
