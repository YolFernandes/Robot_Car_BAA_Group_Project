#
# Python Rover (PRover)
#
# the Gertbot drivers
import cherrypy
import gertbot as gb
import RPi.GPIO as GPIO
import string
from subprocess import check_output
import time
import curses 


# This is for the development environment:
#BOARD = 1           # Which board we talk to 
#LEFT  = 0           # channel for left track
#RIGHT = 2           # channel for right track

# This is for on the rover:
BOARD = 0           # Which board we talk to 
LEFT  = 0           # channel for left track
RIGHT = 1           # channel for right track

# Forards and backwards are the same for left and right
# The trick is to reverse the motor connections for one  :-) 
RAMP  = gb.RAMP_050 # ramp speed=0.5 seconds
FORWD = gb.MOVE_A
BACKW = gb.MOVE_B
STOP  = gb.MOVE_STOP


# 
# gb.move_brushed(board,channel,direction)
#                 ^^^^^ ^^^^^^^ ^^^^^^^^^ 
#                 ||||| ||||||| ||||||||| 
#                 ||||| ||||||| ||||||||| 
#                 ||||| ||||||| +++++++++--------< Left, right, stop
#                 ||||| +++++++------------------< Which motor on board 0,1,2,3
#                 +++++--------------------------< which board 0,1,2,3


# Main program

screen = curses.initscr()
  
# Open serial port to talk to Gertbot 
gb.open_uart(0)

# Setup the channels for brushed motors
gb.set_mode(BOARD,LEFT,gb.MODE_BRUSH)
gb.set_mode(BOARD,RIGHT,gb.MODE_BRUSH)
# set a ramp-up speed in case motors are big
gb.set_brush_ramps(BOARD,LEFT, RAMP,RAMP,0);
gb.set_brush_ramps(BOARD,RIGHT,RAMP,RAMP,0);

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#first IR sensor
GPIO.setup(13, GPIO.IN)

#Second IR sensor
GPIO.setup(19, GPIO.IN)

#Third IR sensor
GPIO.setup(26, GPIO.IN)


f = 5000
a = 65
b = 56
c = 50
d = 23
stop = 0
offS = 0
offR = 0


while True:
    try:
        lIr = GPIO.input(13)
        mIr = GPIO.input(19)
        rIr = GPIO.input(26)
        time.sleep(0.006)

        if  lIr == 1 and mIr == 0 and rIr == 1:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,a)
            gb.pwm_brushed(BOARD,LEFT,f,a)
            offS = 0
            offR = 0

        elif  lIr == 1 and mIr == 1 and rIr == 0:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,d)
            gb.pwm_brushed(BOARD,LEFT,f,c)
            offS = 1
            offR = 1

        elif  lIr == 0 and mIr == 1 and rIr == 1:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,c)
            gb.pwm_brushed(BOARD,LEFT,f,d)
            offS = 2
            offR = 0

        elif  lIr == 1 and mIr == 0 and rIr == 0:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,b)
            gb.pwm_brushed(BOARD,LEFT,f,a)
            offS = 1
            offR = 1

        elif  lIr == 0 and mIr == 0 and rIr == 1:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,a)
            gb.pwm_brushed(BOARD,LEFT,f,b)
            offS = 2
            offR = 1

        elif lIr == 1 and mIr == 1 and rIr == 1 and offS == 1:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,d)
            gb.pwm_brushed(BOARD,LEFT,f,c)
            offS = 1
            öffR = 1

        elif lIr == 1 and mIr == 1 and rIr == 1 and offS == 2:
            gb.move_brushed(BOARD,RIGHT,FORWD)
            gb.move_brushed(BOARD,LEFT,FORWD)
            gb.pwm_brushed(BOARD,RIGHT,f,c)
            gb.pwm_brushed(BOARD,LEFT,f,d)
            offS = 2
            offR = 1

        else :
            gb.move_brushed(BOARD, RIGHT, STOP)
            gb.move_brushed(BOARD, LEFT, STOP)
            time.sleep (0.5)
            gb.move_brushed(BOARD, RIGHT, FORWD)
            gb.move_brushed(BOARD, LEFT, BACKW)
            gb.pwm_brushed(BOARD,RIGHT,f,c)
            gb.pwm_brushed(BOARD,LEFT,f,c)
            time.sleep(2)
            run = 0
            break


            '''
            #GET ON THE LINE AGAIN (turning right)
        elif mSensor == 1 and lSensor == 1 and rSensor == 1 and offTL == 1 :
            gb.pwm_brushed(BOARD,LEFT,5000,fast)# To control the power
            gb.pwm_brushed(BOARD,RIGHT,5000,5)# To control the power
            gb.move_brushed(BOARD,LEFT,FORWD) #Left wheel forward
            gb.move_brushed(BOARD,RIGHT,FORWD)# Right wheel forward
            print("emergency right")
            '''



    except KeyboardInterrupt:
        run = 0
        break

# on exit stop everything
gb.emergency_stop()
# Set terminal behaviour normal again
curses.endwin()

