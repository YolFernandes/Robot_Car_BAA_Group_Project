import cherrypy
import string
import gertbot as gb
from subprocess import check_output
import time


ipaddr = check_output(['hostname','-I']).strip().decode('utf-8')

file = open ('/home/pi/index_webCar.html')
html_index = file.read()
file.close()
html_index = html_index.format(IP=ipaddr)

BOARD = 0           # Which board we talk to 
LEFT  = 0           # channel for left track
RIGHT = 1           # channel for right track

RAMP  = gb.RAMP_050 # ramp speed=0.5 seconds
FORWD = gb.MOVE_A
BACKW = gb.MOVE_B
STOP  = gb.MOVE_STOP

# Open serial port to talk to Gertbot 
gb.open_uart(0)

# Setup the channels for brushed motors
gb.set_mode(BOARD,LEFT,gb.MODE_BRUSH)
gb.set_mode(BOARD,RIGHT,gb.MODE_BRUSH)
# set a ramp-up speed in case motors are big
gb.set_brush_ramps(BOARD,LEFT, RAMP,RAMP,0);
gb.set_brush_ramps(BOARD,RIGHT,RAMP,RAMP,0);

class LEDController(object):

    global html_index
    
    @cherrypy.expose
    def index(self):
        
        return html_index

    @cherrypy.expose
    def forward(self):
        gb.move_brushed(BOARD,LEFT,FORWD)  # Left forwards 
        gb.pwm_brushed(BOARD,LEFT,5000,40)
        gb.move_brushed(BOARD,RIGHT,FORWD) # Right forwards 
        gb.pwm_brushed(BOARD,RIGHT,5000,40)
        return html_index

    @cherrypy.expose
    def turnLeft(self):
        gb.move_brushed(BOARD,LEFT,FORWD)
        gb.move_brushed(BOARD,RIGHT,BACKW)
        return html_index

    @cherrypy.expose
    def STOP(self):
        gb.move_brushed(BOARD,LEFT,STOP) # Left stop
        gb.move_brushed(BOARD,RIGHT,STOP) # Right stop

        return html_index

    @cherrypy.expose
    def turnRight(self):
        gb.move_brushed(BOARD,LEFT,BACKW)
        gb.move_brushed(BOARD,RIGHT,FORWD)
        return html_index

    @cherrypy.expose
    def reverse(self):
        gb.move_brushed(BOARD,LEFT,BACKW) # Left backwards
        gb.move_brushed(BOARD,RIGHT,BACKW) # Right backwards

        return html_index

cherrypy.server.socket_host = ipaddr
cherrypy.quickstart(LEDController())
