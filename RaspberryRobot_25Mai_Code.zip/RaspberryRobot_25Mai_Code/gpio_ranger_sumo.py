#!/usr/bin/python

import time
import datetime
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

GPIO.setup(15,GPIO.OUT)
GPIO.setup(16,GPIO.IN)
GPIO.setup(18,GPIO.IN)
GPIO.setup(21,GPIO.OUT)
GPIO.setup(22,GPIO.OUT)
GPIO.setup(23,GPIO.OUT)

def reading(sensor):
    pingtime = 0
    echotime = 0
    
    if sensor == 0:
        GPIO.output(15,GPIO.LOW)

        #if(GPIO.input(18)==1):
        #    print("HIGH")
        #else:
        #    print("LOW")

        GPIO.output(15,GPIO.HIGH)
        pingtime=time.time()
        time.sleep(0.00001)
        GPIO.output(15,GPIO.LOW)

        while GPIO.input(16)==0:
            pingtime = time.time()

        while GPIO.input(16)==1:
            echotime=time.time()

        if (echotime is not None) and (pingtime is not None):
            elapsedtime = echotime - pingtime
            distance = elapsedtime * 17000
        else:
            distance = 0

        print(pingtime)
        print(echotime)
              
        if distance < 10:
            GPIO.output(21,GPIO.HIGH)
            GPIO.output(22,GPIO.LOW)
            GPIO.output(23,GPIO.LOW)
            print("RED")
        elif distance < 20 and distance >= 10:
            GPIO.output(21,GPIO.LOW)
            GPIO.output(22,GPIO.HIGH)
            GPIO.output(23,GPIO.LOW)
            print("AMBER")
        elif distance >= 20:
            GPIO.output(21,GPIO.LOW)
            GPIO.output(22,GPIO.LOW)
            GPIO.output(23,GPIO.HIGH)
            print("GREEN") 

        return distance

while True:    
    #print(reading(0))
    range = reading(0)
    print(range)
    print()
    time.sleep(0.25)

 
