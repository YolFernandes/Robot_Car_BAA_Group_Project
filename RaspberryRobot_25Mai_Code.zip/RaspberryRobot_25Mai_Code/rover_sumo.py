#
# Python Rover (PRover)
#
# the Gertbot drivers
import gertbot as gb





# Hans/Yolanda >>
# new sumo-code begin
import time
import datatime
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

# GPIO.setup(15,GPIO.OUT)
# GPIO.setup(16,GPIO.IN)
# GPIO.setup(18,GPIO.IN)
# GPIO.setup(21,GPIO.OUT)
# GPIO.setup(22,GPIO.OUT)
# GPIO.setup(23,GPIO.OUT)

# Hans/Yolanda <<






# Using curses to repond to single keyboard keys
import curses 

# This is for the development environment:
BOARD = 0           # Which board we talk to 
LEFT  = 0           # channel for left track
RIGHT = 2           # channel for right track

# This is for on the rover:
#BOARD = 0           # Which board we talk to 
#LEFT  = 0           # channel for left track
#RIGHT = 1           # channel for right track

# Forards and backwards are the same for left and right
# The trick is to reverse the motor connections for one  :-) 
RAMP  = gb.RAMP_050 # ramp speed=0.5 seconds
FORWD = gb.MOVE_A
BACKW = gb.MOVE_B
STOP  = gb.MOVE_STOP

# 
# gb.move_brushed(board,channel,direction)
#                 ^^^^^ ^^^^^^^ ^^^^^^^^^ 
#                 ||||| ||||||| ||||||||| 
#                 ||||| ||||||| ||||||||| 
#                 ||||| ||||||| +++++++++--------< Left, right, stop
#                 ||||| +++++++------------------< Which motor on board 0,1,2,3
#                 +++++--------------------------< which board 0,1,2,3


# Main program

# Get the curses screen
screen = curses.initscr()
  
# Open serial port to talk to Gertbot 
gb.open_uart(0)

# Setup the channels for brushed motors
gb.set_mode(BOARD,LEFT,gb.MODE_BRUSH)
gb.set_mode(BOARD,RIGHT,gb.MODE_BRUSH)
# set a ramp-up speed in case motors are big
gb.set_brush_ramps(BOARD,LEFT, RAMP,RAMP,0);
gb.set_brush_ramps(BOARD,RIGHT,RAMP,RAMP,0);
    
# Tell user what to expect
# in curses print does not work anymore. use addstr
screen.addstr("Gertbot example program for Python\n")
screen.addstr("Use numeric keypad keys control\n")
screen.addstr("Left  Both  Right\n")
screen.addstr("     Forward     \n")
screen.addstr("  7     8     9  \n")
screen.addstr("                 \n")
screen.addstr("  4    Stop   6  \n")
screen.addstr("                 \n")
screen.addstr("  1     2     3  \n")
screen.addstr("     Reverse     \n")
screen.addstr("Left  Both  Right\n")
screen.addstr("Don't forget to set numlock on!!!!\n")
screen.addstr("Use Q or q to quit\n")
screen.addstr("\n")


# Hans/Yolanda >>
# new sumo-code begin

# this code section make activating the motors/wheels
gb.move_brushed(BOARD, LEFT, FORWD)
# in this code section we put the parameters > 10000 for the frequency and 20 is duty cycle for the pwm function
gb.pwm_brushed(BOARD, LEFT, 10000, 20)

gb.move_brushed(BOARD, RIGHT, FORWD)
gb.pwm_brushed(BOARD, RIGHT, 10000, 20)

# this code section 
 if sensor == 0:
        GPIO.output(15,GPIO.LOW)

        #if(GPIO.input(18)==1):
        #    print("HIGH")
        #else:
        #    print("LOW")

        GPIO.output(15,GPIO.HIGH)
        pingtime=time.time()
        time.sleep(0.00001)
        GPIO.output(15,GPIO.LOW)

        while GPIO.input(16)==0:
            pingtime = time.time()

        while GPIO.input(16)==1:
            echotime=time.time()

        if (echotime is not None) and (pingtime is not None):
            elapsedtime = echotime - pingtime
            distance = elapsedtime * 17000
        else:
            distance = 0

        print(pingtime)
        print(echotime)
            elapsedtime = echotime - pingtime
            distance = elapsedtime * 17000
        else:
            distance = 0

        print(pingtime)
        print(echotime)


# Hans/Yolanda <<

run = 1
while run==1 :
  key = screen.getch() # Key?
  if key==ord('q') :
    run = 0 # stop running
    
  if key==ord('1') : 
     gb.move_brushed(BOARD,LEFT,BACKW) # Left backwards 

  if key==ord('2') : 
     gb.move_brushed(BOARD,LEFT,BACKW)  # Left backwards 
     gb.move_brushed(BOARD,RIGHT,BACKW) # Right backwards 

  if key==ord('3') : 
     gb.move_brushed(BOARD,RIGHT,BACKW) # Right backwards 

  if key==ord('4') :
     gb.move_brushed(BOARD,LEFT,STOP) # Left stop 

  if key==ord('5') : 
     gb.move_brushed(BOARD,LEFT,STOP)  # Left stop 
     gb.move_brushed(BOARD,RIGHT,STOP) # Right stop 

  if key==ord('6') :
     gb.move_brushed(BOARD,RIGHT,STOP) # Right stop 

  if key==ord('7') :
     gb.move_brushed(BOARD,LEFT,FORWD) # Left forwards 

  if key==ord('8') :
     gb.move_brushed(BOARD,LEFT,FORWD)  # Left forwards 
     gb.move_brushed(BOARD,RIGHT,FORWD) # Right forwards 

  if key==ord('9') :
     gb.move_brushed(BOARD,RIGHT,FORWD) # Right forwards 

# on exit stop everything
gb.emergency_stop()
# Set terminal behaviour normal again
curses.endwin()

